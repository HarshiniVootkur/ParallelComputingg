
make hello
./hello > hello_answer
